# 🎣 CATCHGBT → BAITBUDDY REBRANDING

**Ziel**: App vollständig umbenennen auf "BaitBuddy"  
**Zeit**: ~20 Minuten (automatisiert)  
**Status**: SCHRITT-FÜR-SCHRITT  

---

# 📝 WAS WIRD UMBENANNT?

```
VORHER (CatchGBT)          NACHHER (BaitBuddy)
─────────────────          ──────────────────
App Name                   BaitBuddy
Brand Name                 BaitBuddy
Package Names              baitbuddy-* 
GitHub Repos              baitbuddy (wenn du willst)
Domains                   baitbuddy.com (später)
Database Names            baitbuddy_*
Code References           baitbuddy everywhere
Branding/Colors           Neues Design
```

---

# ✅ SCHRITT 1: Code Rebranding (5 min)

## 1.1 Frontend umbenennen

```bash
cd catchgbt-backend/..  # Gehe zur Root
mv catchgbt baitbuddy-app

cd baitbuddy-app
# Ändere in package.json:
{
  "name": "baitbuddy-app",
  "version": "1.0.0",
  "description": "BaitBuddy - Your AI Fishing Assistant",
  ...
}
```

## 1.2 Backend umbenennen

```bash
cd ../catchgbt-backend
mv catchgbt-backend baitbuddy-backend

cd baitbuddy-backend
# Ändere in package.json:
{
  "name": "baitbuddy-backend",
  "version": "2.1.0",
  "description": "BaitBuddy Backend - Enterprise Fishing API",
  ...
}
```

## 1.3 Alle Code-Referenzen ersetzen

```bash
# Alle Dateien durchsuchen und ersetzen:
find . -type f -name "*.js" -o -name "*.jsx" -o -name "*.ts" -o -name "*.tsx" | \
xargs sed -i 's/catchgbt/baitbuddy/g' && \
xargs sed -i 's/CatchGBT/BaitBuddy/g' && \
xargs sed -i 's/CATCHGBT/BAITBUDDY/g'

# Auch in HTML/JSON:
find . -type f \( -name "*.html" -o -name "*.json" -o -name "*.md" \) | \
xargs sed -i 's/catchgbt/baitbuddy/g' && \
xargs sed -i 's/CatchGBT/BaitBuddy/g'
```

---

# ✅ SCHRITT 2: Frontend Config (3 min)

## 2.1 baitbuddy-app/vite.config.js

```javascript
export default defineConfig({
  plugins: [react()],
  base: '/',
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true
      }
    }
  }
})

// Auch in index.html:
<title>BaitBuddy - AI Fishing Assistant</title>
<meta name="description" content="BaitBuddy: Your AI-powered fishing companion">
```

## 2.2 baitbuddy-app/public (Favicon, Logos)

```bash
# Erstelle oder update:
public/
├── favicon.ico           (BaitBuddy Logo)
├── logo.png             (BaitBuddy Logo)
└── logo-192x192.png    (App Icon)

# Ändere in manifest.json:
{
  "name": "BaitBuddy",
  "short_name": "BaitBuddy",
  "description": "AI Fishing Assistant",
  "icons": [
    {
      "src": "/logo-192x192.png",
      "sizes": "192x192",
      "type": "image/png"
    }
  ]
}
```

---

# ✅ SCHRITT 3: Backend Config (3 min)

## 3.1 baitbuddy-backend/src/server.js

```javascript
app.listen(PORT, () => {
  console.log(`✅ BaitBuddy Backend v2.1.0 läuft auf Port ${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`   Routes: 12 Files, 92 Endpoints`);
});

// Health endpoint:
app.get('/health', (req, res) => res.json({ 
  ok: true, 
  app: 'BaitBuddy',
  version: '2.1.0-phase1', 
  timestamp: new Date().toISOString() 
}));
```

## 3.2 baitbuddy-backend/.env.example

```bash
# BaitBuddy Backend Configuration
APP_NAME=BaitBuddy
APP_VERSION=2.1.0-phase1
APP_DESCRIPTION=AI-Powered Fishing Assistant

# ... rest der vars bleiben gleich
```

---

# ✅ SCHRITT 4: Database Rebranding (5 min)

## 4.1 Supabase Tables umbenennen (optional)

```sql
-- In Supabase SQL Editor:

-- Old tables → New tables (optional)
ALTER TABLE catches RENAME TO baitbuddy_catches;
ALTER TABLE spots RENAME TO baitbuddy_spots;
ALTER TABLE clans RENAME TO baitbuddy_clans;
-- etc...

-- ODER: Behalte alte Namen, nutze Prefix in Queries
-- Das ist einfacher!
```

## 4.2 Storage Bucket umbenennen

```
Supabase Dashboard → Storage → Buckets

Rename:
- catchgbt-photos → baitbuddy-photos
- catchgbt-assets → baitbuddy-assets
```

---

# ✅ SCHRITT 5: GitHub Repository umbenennen (3 min)

```
GitHub → Repo Settings → Danger Zone

1. Repository name: catchgbt
   → Ändere zu: baitbuddy

2. GitHub gibt dir neue URL:
   https://github.com/USERNAME/baitbuddy

3. Lokal aktualisieren:
   git remote set-url origin https://github.com/USERNAME/baitbuddy
   git push -u origin main
```

---

# ✅ SCHRITT 6: Vercel + Railway Redeployment (5 min)

## 6.1 Vercel aktualisieren

```
Vercel Dashboard → Project Settings

1. Project Name:
   - Ändere zu: baitbuddy

2. Root Directory:
   - Ändere zu: ./baitbuddy-app

3. Redeploy:
   - Push neue Version zu GitHub
   - Vercel deployed automatisch
```

## 6.2 Railway aktualisieren

```
Railway Dashboard → Project Settings

1. Project Name:
   - Ändere zu: baitbuddy-backend

2. Root Directory:
   - Ändere zu: ./baitbuddy-backend

3. Redeploy:
   - Railway deployed automatisch
```

---

# 📊 BRANDING UPDATES

## 6.3 Vercel Domain (optional)

```
Vercel Dashboard → Domains

Old: catchgbt.vercel.app
New: baitbuddy.vercel.app

Oder custom domain:
- baitbuddy.com (wenn verfügbar)
- baitbuddy.app
```

---

# 🎨 DESIGN UPDATES (Optional aber empfohlen)

## 7.1 Colors & Branding

```javascript
// baitbuddy-app/src/theme/colors.js
export const colors = {
  primary: '#0099FF',      // BaitBuddy Blue
  secondary: '#00D4FF',    // Bright Cyan
  accent: '#FF6B6B',       // Coral Red
  dark: '#1A1F3A',         // Dark Navy
  success: '#2ECC71',      // Green
  warning: '#F39C12',      // Orange
  danger: '#E74C3C'        // Red
}

// BaitBuddy Logo/Brand
// Fisch + "BB" Icon
```

## 7.2 App Icons

```
Erstelle neue BaitBuddy Icons:
- 192x192 (App Icon)
- 512x512 (Logo)
- 1024x1024 (Marketing)

Optionen:
1. AI generieren (Hugging Face)
2. Design kaufen (Fiverr, Upwork)
3. AI Design Tool (Canva)
```

---

# ✅ SCHRITT 7: Testing nach Rebranding (3 min)

```bash
# 1. Lokal testen
cd baitbuddy-app && npm run dev
cd ../baitbuddy-backend && npm run dev

# 2. Checke:
- Frontend lädt ✅
- Backend lädt ✅
- Login funktioniert ✅
- "BaitBuddy" überall angezeigt ✅
- Keine Console Errors ✅

# 3. Production testen:
- https://baitbuddy.vercel.app ✅
- https://baitbuddy-backend.railway.app/health ✅

# 4. Git push
git add .
git commit -m "Rebrand: CatchGBT → BaitBuddy"
git push origin main
```

---

# 📋 REBRANDING CHECKLIST

- [ ] Frontend Ordner umbenannt (catchgbt → baitbuddy-app)
- [ ] Backend Ordner umbenannt (catchgbt-backend → baitbuddy-backend)
- [ ] package.json updated (Frontend + Backend)
- [ ] Alle Code-Referenzen ersetzt (sed commands)
- [ ] Vite config aktualisiert
- [ ] Manifest.json updated
- [ ] Server.js Health-Endpoint updated
- [ ] .env.example updated
- [ ] GitHub Repo umbenannt
- [ ] Vercel Projekt aktualisiert
- [ ] Railway Projekt aktualisiert
- [ ] Supabase Storage Buckets umbenannt (optional)
- [ ] Neues Branding/Logo erstellt
- [ ] Lokal getestet
- [ ] Production getestet
- [ ] Git pusht erfolgreich
- [ ] 🚀 Vercel auto-deployed

---

# 🔗 AUTOMATISIERTES REBRANDING SCRIPT

Wenn du alles auf einmal machen willst:

```bash
#!/bin/bash
# rebranding.sh

echo "🎣 Starting CatchGBT → BaitBuddy Rebranding..."

# 1. Rename Directories
echo "1. Renaming directories..."
mv catchgbt baitbuddy-app
mv catchgbt-backend baitbuddy-backend

# 2. Update Code References
echo "2. Updating code references..."
find . -type f \( -name "*.js" -o -name "*.jsx" -o -name "*.json" -o -name "*.md" \) -exec sed -i '' \
  -e 's/catchgbt/baitbuddy/g' \
  -e 's/CatchGBT/BaitBuddy/g' \
  -e 's/CATCHGBT/BAITBUDDY/g' {} \;

# 3. Update Git
echo "3. Updating git remote..."
git remote set-url origin https://github.com/USERNAME/baitbuddy

# 4. Git Commit
echo "4. Committing changes..."
git add .
git commit -m "Rebrand: CatchGBT → BaitBuddy (v2.1.0)"
git push origin main

echo "✅ Rebranding complete!"
echo "📝 Next steps:"
echo "  1. Update Vercel project name"
echo "  2. Update Railway project name"
echo "  3. Test on production"
echo "  4. 🚀 GO LIVE!"
```

---

# 📲 SOCIAL MEDIA / MARKETING

Nach dem Rebranding:

```
Ankündigung:
"🎣 Exciting news! CatchGBT is now BaitBuddy!
Same great AI fishing assistant, new name.
Why the rebrand? Better reflects what we do:
Be your fishing buddy, powered by AI.

Try it now: https://baitbuddy.vercel.app"

Hashtags:
#BaitBuddy #FishingAI #Fishing #AIAssistant
```

---

# 🎯 NÄCHSTE SCHRITTE

Nach Rebranding:

1. ✅ Lokal testen (npm run dev)
2. ✅ Git push
3. ✅ Vercel auto-deploy warten
4. ✅ Railway auto-deploy warten
5. ✅ Production testen
6. ✅ Announce auf Social Media
7. 🎉 **BAITBUDDY IS LIVE!**

---

# ⚠️ WICHTIG

**Backup machen VOR Rebranding!**

```bash
# Backup alte Version
cp -r catchgbt catchgbt-backup
cp -r catchgbt-backend catchgbt-backend-backup

# Falls was schief geht:
rm -rf baitbuddy-app baitbuddy-backend
mv catchgbt-backup catchgbt
mv catchgbt-backend-backup catchgbt-backend
```

---

**Status**: ✅ READY TO REBRAND  
**Next**: Führe die 7 Schritte aus + teste!

