# CatchGBT – Migration von Base44 zur eigenen Infrastruktur
*Analyse des Repos: github.com/smokemoney81/catchgbt*

---

## 1. Was Base44 aktuell alles übernimmt

### 1.1 Authentication & User-Management
Base44 stellt das komplette Auth-System bereit:

- Login / Logout / Session via `base44.auth`
- `base44.auth.me()` → liefert das User-Objekt
- `base44.auth.redirectToLogin(returnUrl)`
- `base44.auth.logout(returnUrl)`
- Token wird in `localStorage` als `base44_access_token` gespeichert

**User-Felder die ihr Code aktiv nutzt (müssen in eigener DB vorhanden sein):**

| Feld | Typ | Beschreibung |
|------|-----|--------------|
| `id` | string | User-ID |
| `email` | string | E-Mail |
| `full_name` | string | Name |
| `nickname` | string | Anzeigename |
| `profile_picture_url` | string | Avatar-URL |
| `premium_plan_id` | string | `free / basic / pro / elite / ultimate` |
| `premium_expires_at` | datetime | Ablauf des Abos |
| `credits` | number | Guthaben |
| `settings` | object | App-Einstellungen |
| `quiz_points` / `quiz_runs` | number | Quiz-Statistiken |
| `referral_code` | string | Empfehlungscode |
| `is_demo_user` | boolean | Demo-Modus |
| `has_had_trial` | boolean | Trial genutzt |
| `tutorial_prompt_seen` | boolean | Tutorial gesehen |
| `feature_ratings` / `feature_usage` | object | Feature-Tracking |
| `first_open_at` | datetime | Erstöffnung |
| `total_earned` | number | Wallet-Summe |

---

### 1.2 Datenbank-Entitäten (via Base44 Entity API)

Diese Entitäten werden in den Backend-Functions direkt abgerufen (`base44.asServiceRole.entities.*`):

| Entity | Beschreibung |
|--------|-------------|
| `Catch` | Fangbuch-Einträge |
| `Spot` | Angelplätze |
| `RuleEntry` | Schonzeiten / Fischereiregeln |
| `FishingClub` | Angelvereine / Angelparks |
| `Clan` | Community-Clans |
| `ClanCatch` | Fänge innerhalb eines Clans |
| `Competition` | Community-Wettbewerbe |
| `VotingSubmission` | Fang-Voting-Einreichungen |
| `VotingLike` | Likes auf Voting-Einreichungen |
| `DepthDataPoint` | Bathymetrie-Crowd-Daten |
| `BathymetricMap` | Tiefenkarten |
| `WaterAnalysisHistory` | Wasseranalyse-Verlauf |
| `PremiumWallet` | Guthaben-Transaktionen |
| `PremiumEvent` | Premium-Ereignisse |
| `AppEvent` | App-Events (Logging) |
| `UsageSession` | Feature-Nutzungs-Sessions (inkl. Credits-Abrechnung) |
| `TrackingEvent` | Seiten- und Feature-Klick-Tracking |

---

### 1.3 Backend-Functions (Deno-basiert, müssen zu eigenen API-Endpunkten werden)

Alle 56 Functions laufen aktuell auf Deno / Base44 Serverless. Diese werden vom Frontend via `base44.functions.invoke('name', params)` aufgerufen.

**Im Frontend aktiv genutzte Functions (18 von 56):**

| Function | Zweck | Benötigt |
|----------|-------|----------|
| `catchgbtChat` | KI-Chat (Marina / BaitBuddy) | LLM (Gemini/Claude), DB-Zugriff |
| `analyzeCatchPhoto` | Fisch-Foto-Analyse mit KI | LLM + Bildverarbeitung |
| `angelspotsGeojson` | Angelplätze als GeoJSON | DB |
| `bathymetryProxy` | Bathymetrie-Daten-Proxy | Externe API |
| `textToSpeech` | Text-zu-Sprache | ElevenLabs API |
| `getPlanStatus` | Premium-Plan des Nutzers prüfen | DB (User) |
| `activatePlan` | Plan aktivieren | DB |
| `createStripeCheckoutSession` | Stripe Checkout starten | Stripe API |
| `calculateTravelTime` | Fahrtzeit berechnen | OpenRouteService API |
| `deleteAccount` | Account löschen | DB |
| `addVotingLike` | Like auf Voting-Einreichung | DB |
| `createClan` | Clan erstellen | DB |
| `joinClan` | Clan beitreten | DB |
| `getClanLeaderboard` | Clan-Rangliste | DB |
| `getVotingLeaderboard` | Voting-Rangliste | DB |
| `startCommunityCompetition` | Wettbewerb starten | DB |
| `cleanupOldSessions` | Sessions aufräumen | DB |
| `verifyPlayIntegrity` | Google Play Integrity | Google API |

**Weitere vorhandene Functions (nicht direkt vom Frontend aufgerufen, aber vorhanden):**
`aiEvaluateCatch`, `autoRenewPlans`, `backendTextToSpeech`, `checkFeatureAccess`, `detectHotspots`, `freeNeuralTTS`, `geminiTextToSpeech`, `generateBathymetricMap`, `generateCatchReport`, `geocodeFishingClubs`, `getEventLeaderboard`, `getFishingRecommendation`, `getPremiumProducts`, `getPremiumWalletStatus`, `getSatelliteData`, `getWaterData`, `getWeatherForLocation`, `heartbeatPremiumMeter`, `loadWaterBodies`, `predictFishing`, `premiumStatus`, `processDepthData`, `purchasePremium`, `startPremiumMeter`, `stopPremiumMeter`, `stripeWebhookHandler`, `submitClanCatch`, `submitVotingCatch`, `trainFishingModel`, `adminAssignPlan`, `adminResetWallet`, `adminSetCredits`, `activateDemoMode`, `addVotingLike`

---

### 1.4 Base44 Integrations (direkt im Frontend genutzt)

| Integration | Genutzt für |
|-------------|-------------|
| `InvokeLLM` | KI-Antworten (BaitBuddy, Schonzeit-Checker, etc.) |
| `UploadFile` | Foto-Upload (Community-Posts, Fang-Fotos) |
| `SendEmail` | (vorbereitet, ggf. nicht aktiv) |
| `SendSMS` | (vorbereitet) |
| `GenerateImage` | (vorbereitet) |
| `ExtractDataFromUploadedFile` | (vorbereitet) |

---

### 1.5 Benötigte Umgebungsvariablen (Secrets)

| Variable | Dienst | Verwendung |
|----------|--------|------------|
| `STRIPE_SECRET_KEY` | Stripe | Checkout Sessions |
| `STRIPE_WEBHOOK_SECRET` | Stripe | Webhook-Verifikation |
| `ELEVENLABS_API_KEY` | ElevenLabs | Text-to-Speech |
| `OPEN_ROUTE_SERVICE_API_KEY` | OpenRouteService | Fahrtzeit-Berechnung |
| `VITE_BASE44_APP_ID` | Base44 | App-ID (Frontend) |
| `VITE_BASE44_BACKEND_URL` | Base44 | Backend-URL (Frontend) |

---

### 1.6 Externe APIs (bereits in den Functions integriert)

| API | URL | Zweck |
|-----|-----|-------|
| ElevenLabs | `api.elevenlabs.io` | TTS |
| Open-Meteo | `api.open-meteo.com` | Wetter (kostenlos) |
| Overpass API | `overpass-api.de` | OSM-Angelplätze |
| Google OAuth2 | `oauth2.googleapis.com` | Play Integrity |

---

## 2. Frontend-Techstack (bleibt erhalten)

- **React 18** + **Vite 6**
- **React Router 6** (SPA-Routing)
- **Tailwind CSS 3** + Radix UI + shadcn/ui
- **Framer Motion** (Animationen)
- **React Leaflet** (Karte)
- **Recharts** (Statistiken)
- **Three.js** (AR/3D)
- **Stripe React** (Checkout)
- **@tanstack/react-query 5** (Server State)
- **Zod** (Validierung)
- **date-fns / moment** (Datum)

→ **Der gesamte Frontend-Code kann 1:1 übernommen werden.** Nur `src/api/base44Client.js`, `src/api/entities.js`, `src/api/integrations.js` und `src/lib/AuthContext.jsx` müssen neu geschrieben werden.

---

## 3. Migrations-Reihenfolge (empfohlen)

### Phase 1 – Backend aufsetzen (Node.js/Express auf Railway/Render)
1. PostgreSQL-Datenbank mit allen Entitäten anlegen (Supabase empfohlen: Auth + DB + Storage in einem)
2. Auth-System implementieren (Supabase Auth oder eigenes JWT)
3. API-Endpunkte für alle 18 genutzten Functions als Express-Routes portieren
4. Stripe Webhook-Handler einrichten
5. ElevenLabs + OpenRouteService Keys übertragen

### Phase 2 – Frontend umklemmen
1. `base44Client.js` → eigener `apiClient.js` mit Axios/Fetch + JWT-Header
2. `AuthContext.jsx` → auf Supabase Auth oder eigenes JWT umstellen
3. `base44.functions.invoke('name', params)` → `apiClient.post('/api/name', params)`
4. `base44.integrations.Core.InvokeLLM` → direkter Anthropic/Gemini API-Call
5. `base44.integrations.Core.UploadFile` → Supabase Storage oder S3
6. Vite-Plugin `@base44/vite-plugin` entfernen

### Phase 3 – Daten-Migration
- Alle bestehenden Nutzer + Entities aus Base44 exportieren (CSV/JSON)
- In neue PostgreSQL-DB importieren

---

## 4. Empfohlener Stack für Migration

| Bereich | Empfehlung | Begründung |
|---------|------------|------------|
| **Auth + DB + Storage** | Supabase | Ersetzt Base44 fast 1:1, hat eigenes Auth, RLS, File-Storage |
| **Backend-Functions** | Supabase Edge Functions (Deno!) | Deno-Code kann fast 1:1 übernommen werden! |
| **LLM** | Anthropic Claude API | `InvokeLLM` → `claude-sonnet-4-6` |
| **Hosting Frontend** | Vercel | Bereits in `src/vercel.json` vorbereitet |
| **Hosting Backend** | Supabase oder Railway | |

> **Wichtiger Hinweis:** Da alle Backend-Functions bereits in **Deno/TypeScript** geschrieben sind und Supabase Edge Functions ebenfalls Deno nutzen, ist der Code fast ohne Änderungen portierbar – nur `createClientFromRequest` und `base44.asServiceRole.entities.*` müssen durch Supabase-Client-Calls ersetzt werden.
