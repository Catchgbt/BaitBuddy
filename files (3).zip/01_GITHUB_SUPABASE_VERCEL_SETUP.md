# 🔧 SETUP ANLEITUNG: GitHub + Supabase + Vercel

**Ziel**: Alle 3 Plattformen konfigurieren und verbinden  
**Zeit**: ~30 Minuten  
**Status**: SCHRITT-FÜR-SCHRITT  

---

# 📋 ZUSAMMENFASSUNG DER 3 SCHRITTE

```
1. GITHUB           (10 min) - Code Repository
   ├─ Account erstellen/Login
   ├─ CatchGBT Repo clonen
   └─ SSH Key einrichten

2. SUPABASE         (10 min) - Database + Auth
   ├─ Projekt erstellen
   ├─ Schema.sql ausführen
   └─ Keys kopieren

3. VERCEL + RAILWAY (10 min) - Deployment
   ├─ Vercel Projekt erstellen
   ├─ Railway Projekt erstellen
   └─ Env Variablen setzen
```

---

# ✅ SCHRITT 1: GitHub Setup (10 min)

## 1.1 GitHub Account

```
1. Gehe zu https://github.com
2. "Sign up" OR "Sign in" wenn du schon Account hast
3. Falls neu:
   - Email eingeben
   - Password erstellen
   - Email bestätigen
   - Fertig!
```

## 1.2 CatchGBT Repo clonen

```bash
# Option A: Über HTTPS (einfacher)
git clone https://github.com/smokemoney81/catchgbt.git
cd catchgbt

# Option B: Über SSH (besser für Deployment)
git clone git@github.com:smokemoney81/catchgbt.git
cd catchgbt
```

## 1.3 SSH Key Setup (für Deployment nötig)

### Nur wenn du SSH nutzen willst:

```bash
# 1. SSH Key generieren
ssh-keygen -t ed25519 -C "deine@email.com"
# → Enter drücken für alles (default locations)
# → No passphrase (einfach Enter)

# 2. SSH Key anzeigen
cat ~/.ssh/id_ed25519.pub
# → Ganzen Output kopieren!

# 3. Zu GitHub hinzufügen
GitHub → Settings → SSH and GPG keys → New SSH key
  - Title: "My Computer"
  - Key: [DEIN SSH KEY EINFÜGEN]
  - Add key!

# 4. Test
ssh -T git@github.com
# Sollte sagen: "Hi username! You've successfully authenticated"
```

## 1.4 Repo Struktur Check

```bash
# Backend & Frontend sollten im Repo sein:
ls -la
# catchgbt/              ← Frontend (React)
# catchgbt-backend/      ← Backend (Express)
```

✅ **GitHub ist ready!**

---

# ✅ SCHRITT 2: Supabase Setup (10 min)

## 2.1 Supabase Account

```
1. Gehe zu https://supabase.com
2. "Sign up with GitHub" (einfacher!)
   - Authorize Supabase App
   - GitHub Account verbunden!
3. Oder "Sign up with Email"
   - Email + Password
```

## 2.2 Neues Projekt erstellen

```
1. Supabase Dashboard: https://app.supabase.com
2. Klicke "New Project"
3. Konfiguriere:

   Organization: 
   └─ "Create a new organization" oder wähle existierende

   Project Name:
   └─ catchgbt-prod (oder dein Name)

   Database Password:
   └─ STARKES Passwort eingeben!
   └─ 📝 MERKEN oder speichern!

   Region:
   └─ Europe (Frankfurt) [eu-central-1]
   └─ Am nächsten zu Deutschland!

   Pricing Plan:
   └─ Free tier ist ok für Start
   └─ Later: $25/month für mehr

4. "Create new project"
5. ⏳ Warte 2-3 Minuten auf Setup
```

## 2.3 Database Schema importieren

```
1. Supabase Dashboard → SQL Editor
2. "New Query"
3. Kopiere KOMPLETTEN Inhalt aus:
   → catchgbt-backend/schema.sql
4. Paste in SQL Editor
5. "Run" (grüner Button)
6. ⏳ Warte ~30 Sekunden
7. ✅ "Success" Message
```

## 2.4 API Keys kopieren

```
Supabase Dashboard → Settings → API

Kopiere diese 3 Keys:

1. Project URL
   ├─ Sieht aus wie: https://xxxx.supabase.co
   └─ Speichern als: SUPABASE_URL

2. anon public key
   ├─ Sieht aus wie: eyJhbGc...
   └─ Speichern als: SUPABASE_ANON_KEY

3. service_role key (SECRET!)
   ├─ Sieht aus wie: eyJhbGc...
   └─ Speichern als: SUPABASE_SERVICE_ROLE_KEY
   └─ ⚠️ NIEMALS öffentlich teilen!

📝 Speichere diese in einer Datei!
```

## 2.5 Authentication Konfigurieren

```
Supabase Dashboard → Authentication → Providers

1. Email/Password: 
   └─ Default enabled ✅

2. Redirect URLs (WICHTIG!):
   → Authentication → URL Configuration
   └─ Site URL: http://localhost:5173 (dev)
   └─ Redirect URLs:
      ├─ http://localhost:5173/auth/callback
      ├─ http://localhost:3000/auth/callback
      └─ https://yourdomain.vercel.app/auth/callback (später)
```

✅ **Supabase ist ready!**

---

# ✅ SCHRITT 3: Vercel + Railway Setup (10 min)

## 3.1 Vercel Setup (Frontend Deployment)

### 3.1.1 Account erstellen

```
1. Gehe zu https://vercel.com
2. "Sign up"
3. "Continue with GitHub"
4. Authorize Vercel
5. ✅ Verbunden!
```

### 3.1.2 Frontend Projekt erstellen

```
Vercel Dashboard: https://vercel.com/dashboard

1. "Add New..." → "Project"
2. "Import Git Repository"
3. Wähle: smokemoney81/catchgbt
   ├─ Root Directory: ./catchgbt
   └─ Click "Continue"

4. Environment Variables setzen:
   
   VITE_SUPABASE_URL=https://xxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJhbGc...
   VITE_BACKEND_URL=http://localhost:3000 (dev)
   
   (Später: https://your-backend-railway.app)

5. "Deploy"
6. ⏳ Warte ~3 Minuten
7. ✅ "Congratulations! Your project has been deployed"

Deine Frontend URL:
└─ https://catchgbt.vercel.app (oder dein Name)
```

### 3.1.3 Auto-Deploy einrichten

```
Vercel Dashboard → Project Settings → Git

Deploy on every push to:
└─ Branch: main (oder dein default branch)
└─ Auto-deploy: ON ✅
```

---

## 3.2 Railway Setup (Backend Deployment)

### 3.2.1 Account erstellen

```
1. Gehe zu https://railway.app
2. "Login with GitHub"
3. Authorize Railway
4. ✅ Verbunden!
```

### 3.2.2 Backend Projekt erstellen

```
Railway Dashboard: https://railway.app/dashboard

1. "Create New Project"
2. "Deploy from GitHub Repo"
3. "GitHub Repo wählen"
4. Select repo: smokemoney81/catchgbt
5. Select branch: main

6. Konfiguriere Service:
   └─ Root directory: ./catchgbt-backend
   └─ Build command: npm install
   └─ Start command: npm start
   └─ Port: 3000

7. "Deploy"
8. ⏳ Warte ~5 Minuten
```

### 3.2.3 Environment Variables (WICHTIG!)

```
Railway Dashboard → Project → Variables

Setze ALLE diese:

SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...
SUPABASE_ANON_KEY=eyJhbGc...
JWT_SECRET=dein_secret_hier_123456789
ANTHROPIC_API_KEY=sk-ant-v0-...
STRIPE_SECRET_KEY=sk_live_xxxxx (oder test)
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
ELEVENLABS_API_KEY=xxxxx
DEMO_PASSWORD=demo123
APP_URL=https://dein-backend.railway.app
PORT=3000
NODE_ENV=production

⚠️ WICHTIG: Speichere diese NICHT im Git!
           Nur in Railway/Vercel Environment!
```

### 3.2.4 Backend URL bekommen

```
Railway Dashboard → Project → Domains

"Generate Domain"
└─ dein-backend.railway.app

Kopiere diese URL!
└─ Wird genutzt in Vercel als VITE_BACKEND_URL
```

---

# 🔗 VERBINDUNG TESTEN

## 4.1 Frontend → Backend Test

```bash
# Vercel Frontend öffnen
https://catchgbt.vercel.app

# Browser Console öffnen (F12)
# Versuche zu login

# Falls Error: 
# → Check VITE_BACKEND_URL in Vercel stimmt
# → Check Backend läuft (Railway Dashboard)
# → Check CORS aktiviert im Backend (ist es!)
```

## 4.2 Backend Health Check

```bash
# Test ob Backend läuft:
curl https://dein-backend.railway.app/health

# Sollte antworten:
{"ok":true,"version":"2.1.0-phase1",...}
```

## 4.3 Database Connection Test

```bash
# Login zu Supabase
# Try to insert test data in catches table
# Sollte funktionieren
```

---

# 📊 ÜBERSICHT NACH SETUP

```
GITHUB (Code Repository)
├─ Frontend Code: /catchgbt
├─ Backend Code: /catchgbt-backend
└─ Auto-synced mit Vercel + Railway

SUPABASE (Database + Auth)
├─ PostgreSQL Database (16 Tabellen)
├─ Authentication (JWT)
├─ Realtime Subscriptions
└─ URL: https://xxxx.supabase.co

VERCEL (Frontend Hosting)
├─ React App deployed
├─ Auto-deploy on GitHub push
├─ Global CDN
└─ URL: https://catchgbt.vercel.app

RAILWAY (Backend Hosting)
├─ Express.js deployed
├─ Auto-deploy on GitHub push
├─ Global Edge Network
└─ URL: https://dein-backend.railway.app
```

---

# 📝 CHECKLISTE

- [ ] GitHub Account erstellt/Login
- [ ] CatchGBT Repo geclont
- [ ] SSH Key konfiguriert (optional)
- [ ] Supabase Account erstellt
- [ ] Supabase Projekt erstellt
- [ ] Schema.sql ausgeführt
- [ ] Supabase Keys kopiert
- [ ] Auth URLs konfiguriert
- [ ] Vercel Account erstellt
- [ ] Frontend zu Vercel deployed
- [ ] Railway Account erstellt
- [ ] Backend zu Railway deployed
- [ ] Environment Variables gesetzt
- [ ] Backend URL kopiert
- [ ] Frontend env variable updated
- [ ] Health Check erfolgreich (/health)
- [ ] Frontend → Backend Connection getestet
- [ ] Login funktioniert

---

# 🚨 HÄUFIGE FEHLER

### "Cannot find module"
```
Lösung:
1. Railway → Deployment → Logs
2. Check npm install läuft
3. Check package.json existiert
```

### "CORS Error"
```
Lösung:
1. Backend muss running sein
2. VITE_BACKEND_URL muss stimmen
3. CORS ist im Backend enabled (is it!)
```

### "Auth redirect failed"
```
Lösung:
1. Supabase → Auth → URL Configuration
2. Redirect URL eintragen:
   - http://localhost:5173/auth/callback
   - https://dein-domain.vercel.app/auth/callback
```

### "Database connection failed"
```
Lösung:
1. Check SUPABASE_URL stimmt
2. Check SUPABASE_SERVICE_ROLE_KEY stimmt
3. Check Schema.sql wurde ausgeführt
4. Check Password ist korrekt
```

---

# 🎯 NÄCHSTE SCHRITTE

Nach diesem Setup:

1. ✅ Lokal testen:
   ```bash
   cd catchgbt && npm run dev
   cd catchgbt-backend && npm run dev
   ```

2. ✅ Production testen:
   - https://catchgbt.vercel.app (Frontend)
   - https://dein-backend.railway.app/health (Backend)

3. ✅ Sign up + Login testen

4. ✅ Fang eintragen testen

5. ✅ 🎉 APP LÄUFT!

---

# 📞 SUPPORT

Falls was nicht funktioniert:

1. **Logs checken**:
   - Vercel Dashboard → Logs
   - Railway Dashboard → Logs
   - Browser Console (F12)

2. **URLs prüfen**:
   - VITE_BACKEND_URL in Vercel?
   - SUPABASE_URL in beiden?
   - Alle Keys korrekt?

3. **Lokal debuggen**:
   ```bash
   npm run dev
   # Check für Errors im Output
   ```

4. **Dokumentation**:
   - 00_START_HIER.md
   - FINAL_SUMMARY.md

---

**Status**: ✅ READY FOR NEXT STEPS  
**Next**: Siehe 00_START_HIER.md für weitere Schritte!

