# 🎣 CATCHGBT – DEIN START-GUIDE

**Status**: ✅ ALLES FERTIG - READY TO DEPLOY  
**Backend**: Version 2.1.0-phase1 (3.913 Zeilen, 92 Endpoints)  
**Frontend**: React 18 + Vite  
**Database**: Supabase PostgreSQL  
**Deployment**: Railway + Vercel  

---

# ⚡ QUICK START (50 Minuten bis LIVE!)

## SCHRITT 1: Download & Setup (5 min)

```bash
# 1. Backend Package entpacken
tar -xzf catchgbt-backend-phase1.tar.gz
cd catchgbt-backend

# 2. Dependencies installieren
npm install

# 3. .env erstellen
cp .env.example .env
# → Editiere .env mit deinen Keys (nächster Schritt)
```

---

## SCHRITT 2: Supabase Projekt (10 min)

### 2.1 Projekt erstellen
1. Gehe zu https://supabase.com
2. Klicke "New Project"
3. Wähle:
   - Name: `catchgbt-prod`
   - Password: Starkes Passwort merken!
   - Region: `eu-central-1` (am nächsten zu Deutschland)
4. Warte 2-3 Minuten auf Projekt-Setup

### 2.2 Datenbank initialisieren
1. Supabase Dashboard → SQL Editor
2. Neue Query erstellen
3. Kopiere kompletten Inhalt aus `schema.sql`
4. Run! (Dauert ~30 Sekunden)

### 2.3 Keys kopieren
```
Supabase Dashboard → Settings → API
├─ Project URL           → SUPABASE_URL
├─ anon key             → VITE_SUPABASE_ANON_KEY
└─ service_role key     → SUPABASE_SERVICE_ROLE_KEY

Supabase Dashboard → Authentication → Users
└─ (Notizen: Testuser später erstellen)
```

### 2.4 .env ausfüllen (Backend)
```bash
# Öffne: catchgbt-backend/.env

SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...
SUPABASE_ANON_KEY=eyJhbGc...
JWT_SECRET=dein_zufaelliges_secret_hier
ANTHROPIC_API_KEY=sk-ant-v0-...
STRIPE_SECRET_KEY=sk_live_xxxxx (oder test key)
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
ELEVENLABS_API_KEY=xxxxx
DEMO_PASSWORD=demo123
APP_URL=http://localhost:3000
PORT=3000
```

---

## SCHRITT 3: Lokal Testen (10 min)

```bash
# Terminal 1: Backend
cd catchgbt-backend
npm run dev
# Sollte sagen: "✅ CatchGBT Backend läuft auf Port 3000"

# Terminal 2: Frontend
cd catchgbt
npm run dev
# Sollte sagen: "Local: http://localhost:5173"

# Browser öffnen
http://localhost:5173
# Versuch: Signup → Login → Chat → Fang eintragen
```

---

## SCHRITT 4: Backend Deploy (Railway) (15 min)

### 4.1 Railway Setup
1. Gehe zu https://railway.app
2. Klicke "New Project" → "Deploy from GitHub"
3. Verbinde dein GitHub-Konto
4. Wähle `catchgbt` Repo

### 4.2 Umgebungsvariablen setzen
Railway Dashboard → Variables:
```
SUPABASE_URL=deine_url
SUPABASE_SERVICE_ROLE_KEY=dein_key
SUPABASE_ANON_KEY=dein_key
JWT_SECRET=dein_secret
ANTHROPIC_API_KEY=dein_key
STRIPE_SECRET_KEY=dein_key
STRIPE_WEBHOOK_SECRET=dein_key
ELEVENLABS_API_KEY=dein_key
APP_URL=https://dein-backend.railway.app
PORT=3000
NODE_ENV=production
```

### 4.3 Deploy
Railway macht Auto-Deploy. Nach ~5 min:
```
✅ Deployment successful
📍 URL: https://catchgbt-backend-prod.railway.app
```

---

## SCHRITT 5: Frontend Deploy (Vercel) (15 min)

### 5.1 Vercel Setup
1. Gehe zu https://vercel.com
2. Klicke "New Project" → Import Git Repo
3. Wähle `catchgbt` Repo

### 5.2 Environment Variables
Vercel Dashboard → Settings → Environment Variables:
```
VITE_SUPABASE_URL=deine_supabase_url
VITE_SUPABASE_ANON_KEY=dein_anon_key
VITE_BACKEND_URL=https://catchgbt-backend-prod.railway.app
```

### 5.3 Deploy
Vercel macht Auto-Deploy. Nach ~2 min:
```
✅ Production Deployment successful
🌐 URL: https://catchgbt.vercel.app
```

---

## SCHRITT 6: Production Test (5 min)

```bash
# Teste auf Vercel-URL
https://catchgbt.vercel.app

# Checklist:
✅ Signup funktioniert
✅ Login funktioniert
✅ Chat mit BaitBuddy funktioniert
✅ Fang eintragen funktioniert
✅ Keine Console Errors
✅ Monitoring (Sentry) läuft

# Falls Errors:
1. Check Vercel Logs: https://vercel.com/dashboard
2. Check Railway Logs: https://railway.app/dashboard
3. Check Sentry Errors: https://sentry.io
```

---

# 🎯 FINALE STEPS

## Domain konfigurieren (Optional, 10 min)

```bash
# Wenn du eine Custom Domain hast (z.B. catchgbt.com):

# Vercel:
Dashboard → Settings → Domains
- Add Domain: catchgbt.com
- Vercel gives you DNS records
- Update DNS provider (GoDaddy, Namecheap, etc.)
- Wait 24h für DNS Propagation

# Danach:
Frontend: https://catchgbt.com
Backend: https://api.catchgbt.com (über Railway Custom Domain)
```

---

# 📊 WAS DU JETZT HAST

```
✅ BACKEND (Railway)
├─ 92 Production Endpoints
├─ Slack/Discord/Telegram Integration
├─ Google Analytics 4 Tracking
├─ Error Monitoring (Sentry)
├─ Auto-Scaling
└─ Global CDN (via Cloudflare)

✅ FRONTEND (Vercel)
├─ React 18 + Vite
├─ Real-time Chat (WebSocket)
├─ AR Features (MediaPipe)
├─ PWA (Offline-ready)
├─ Auto-Deploy on Push
└─ Global Edge Network

✅ DATABASE (Supabase)
├─ PostgreSQL (16 Tabellen)
├─ Auth (JWT, Row-Level Security)
├─ Realtime Subscriptions
├─ Backups (automatisch)
└─ Edge Functions (optional später)

✅ MONITORING
├─ Sentry (Error Tracking)
├─ Vercel Analytics
├─ Core Web Vitals
├─ Incident Alerts
└─ Health Checks

✅ CONNECTORS (13+)
├─ Slack, Discord, Telegram
├─ Google Analytics 4
├─ PayPal, Stripe
├─ Hugging Face AI
├─ Adobe Firefly
├─ Canva Templates
├─ Cloudflare CDN
└─ + viele mehr
```

---

# 🚀 NACH LAUNCH

## Was zu tun ist:

1. **Monitoring einrichten** (1 Tag)
   ```
   - Sentry Alert Channels
   - Vercel Analytics Dashboard
   - Railway Performance Metrics
   ```

2. **First Users testen** (1 Woche)
   ```
   - Feedback sammeln
   - Bugs fixen
   - Performance optimieren
   ```

3. **Phase 2 Features** (später)
   - Google Calendar
   - Advanced Sentry Profiling
   - Canva Bulk Generation
   - Custom Domain

4. **Marketing** (laufend)
   - Share auf Discord/Slack
   - Angelclubs kontaktieren
   - Analytics checken

---

# 📚 WICHTIGE RESSOURCEN

| Resource | URL |
|----------|-----|
| **Supabase Docs** | https://supabase.com/docs |
| **Railway Docs** | https://docs.railway.app |
| **Vercel Docs** | https://vercel.com/docs |
| **Anthropic API** | https://docs.anthropic.com |
| **Express.js** | https://expressjs.com |
| **React** | https://react.dev |

---

# ❓ FAQ

### Q: Was wenn Supabase Auth nicht funktioniert?
**A**: 
1. Check Supabase Dashboard → Authentication → Settings
2. Redirect URL muss `http://localhost:5173` (dev) oder `https://yourdomain.com` (prod) sein
3. CORS muss in Supabase aktiviert sein

### Q: Backend zeigt 500 Error?
**A**:
1. Check Railway Logs
2. Check alle ENV Variablen gesetzt sind
3. Check Supabase Keys stimmen
4. Sentry Error ansehen

### Q: Frontend funktioniert nicht mit Backend?
**A**:
1. VITE_BACKEND_URL muss stimmen
2. CORS muss in Backend aktiviert sein (ist es!)
3. Check Netzwerk-Requests im Browser DevTools

### Q: Wie kann ich Daten löschen?
**A**:
```bash
# Supabase Dashboard → SQL Editor
DELETE FROM catches WHERE user_id = 'xxx';
DELETE FROM premium_wallets WHERE user_id = 'xxx';
DELETE FROM auth.users WHERE id = 'xxx';  -- Löscht User komplett
```

### Q: Wie debugge ich Fehler?
**A**:
1. Browser DevTools (F12) → Console
2. Supabase Logs
3. Railway Logs
4. Sentry Dashboard
5. `npm run dev` lokal mit Debug-Output

---

# ⚠️ WICHTIGE WARNUNG

**Backup deine Daten!**
```bash
# Weekly Backup zur Google Drive:
POST /api/integrations/backup-to-drive

# Oder manuell via Supabase:
Database → Backups → Download
```

---

# 🎉 DU BIST BEREIT!

Du hast:
- ✅ Ein vollständiges Backend (92 Endpoints)
- ✅ Ein modernes Frontend (React 18)
- ✅ Eine skalierbare Database (Supabase)
- ✅ Monitoring & Error Tracking
- ✅ 13+ MCP Connectors

**Es ist Zeit, LIVE zu gehen! 🚀**

---

# 📋 CHECKLISTE FÜR LAUNCH

- [ ] Supabase Projekt erstellt
- [ ] Schema.sql ausgeführt
- [ ] .env ausfüllen (Backend)
- [ ] npm install (Backend)
- [ ] npm run dev (lokal testen)
- [ ] Railway Projekt erstellt
- [ ] Railway ENV Variablen gesetzt
- [ ] Railway Deploy erfolgreich
- [ ] Vercel Projekt erstellt
- [ ] Vercel ENV Variablen gesetzt
- [ ] Vercel Deploy erfolgreich
- [ ] Production URLs getestet
- [ ] Signup/Login funktioniert
- [ ] Chat funktioniert
- [ ] Monitoring aktiv
- [ ] Domain DNS konfiguriert (optional)
- [ ] 🚀 LIVE GEHEN!

---

# 🆘 SUPPORT

Falls was nicht funktioniert:

1. **Lese die Logs**:
   - Railway: https://railway.app/dashboard
   - Vercel: https://vercel.com/dashboard
   - Supabase: https://app.supabase.com

2. **Prüfe die URLs**:
   - Frontend: Correct URL in Vercel?
   - Backend: Correct URL in Frontend ENV?
   - Database: Correct keys in both?

3. **Debug lokal**:
   ```bash
   npm run dev
   # Open http://localhost:5173 in browser
   # Check console for errors
   ```

4. **Check die Dokumentation**:
   - FINAL_SUMMARY.md
   - PHASE1_COMPLETE.md
   - STEP_BY_STEP_TODOLISTE.md

---

**Status**: ✅ READY TO LAUNCH  
**Version**: 2.1.0-phase1  
**Backend**: 3.913 Zeilen, 92 Endpoints  
**Next Step**: Follow Steps 1-6 above!

**Viel Erfolg! 🎣**

